export type Plan = 'trial' | 'starter' | 'pro' | 'portfolio'
export type SubscriptionStatus = 'trialing' | 'active' | 'canceled' | 'past_due' | 'incomplete'
export type TransactionType = 'income' | 'expense'
export type PropertyType = 'Single Family' | 'Condo/Townhouse' | 'Multi-Family' | 'Commercial' | 'Vacation Rental' | 'Other'
export type RecurringFrequency = 'monthly' | 'quarterly' | 'annually'

export interface Profile {
  id: string
  full_name: string | null
  email: string | null
  avatar_url: string | null
  created_at: string
  updated_at: string
}

export interface Subscription {
  id: string
  user_id: string
  stripe_customer_id: string | null
  stripe_subscription_id: string | null
  plan: Plan
  status: SubscriptionStatus
  trial_ends_at: string | null
  current_period_end: string | null
  cancel_at_period_end: boolean
  created_at: string
  updated_at: string
}

export interface Property {
  id: string
  user_id: string
  name: string
  address: string
  city: string | null
  state_province: string | null
  zip_postal: string | null
  country: string
  property_type: PropertyType
  monthly_rent: number
  purchase_price: number | null
  purchase_date: string | null
  bedrooms: number | null
  bathrooms: number | null
  square_feet: number | null
  is_active: boolean
  notes: string | null
  created_at: string
  updated_at: string
}

export interface Transaction {
  id: string
  user_id: string
  property_id: string | null
  date: string
  type: TransactionType
  category: string
  description: string | null
  amount: number
  is_recurring: boolean
  recurring_frequency: RecurringFrequency | null
  receipt_url: string | null
  vendor: string | null
  created_at: string
  updated_at: string
  properties?: Pick<Property, 'id' | 'name'>
}

export interface Lease {
  id: string
  user_id: string
  property_id: string
  tenant_name: string
  tenant_email: string | null
  tenant_phone: string | null
  start_date: string
  end_date: string | null
  monthly_rent: number
  security_deposit: number
  is_active: boolean
  notes: string | null
  created_at: string
  updated_at: string
  properties?: Pick<Property, 'id' | 'name' | 'address'>
}

export interface ScheduleELineItem {
  category: string
  amount: number
}

export interface ScheduleEProperty {
  property: Property
  totalIncome: number
  totalExpenses: number
  netIncome: number
  expensesByCategory: Record<string, number>
  incomeByCategory: Record<string, number>
}

export interface PlanConfig {
  id: Plan
  name: string
  monthlyPrice: number
  annualPrice: number
  propertyLimit: number | null
  features: string[]
  stripePriceMonthly?: string
  stripePriceAnnual?: string
}

export interface DashboardMetrics {
  totalIncome: number
  totalExpenses: number
  netIncome: number
  propertyCount: number
  activeLeaseCount: number
  occupancyRate: number
  leasesExpiringIn90Days: number
}
