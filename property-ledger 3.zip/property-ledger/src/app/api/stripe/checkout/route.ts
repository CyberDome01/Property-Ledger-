import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { stripe, getOrCreateStripeCustomer } from '@/lib/stripe'
import { PLANS } from '@/lib/constants'

export async function POST(req: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { planId, billingCycle } = await req.json()
    const plan = PLANS.find((p) => p.id === planId)
    if (!plan) return NextResponse.json({ error: 'Invalid plan' }, { status: 400 })

    const priceId = billingCycle === 'annual' ? plan.stripePriceAnnual : plan.stripePriceMonthly
    if (!priceId) return NextResponse.json({ error: 'Price not configured' }, { status: 400 })

    const { data: profile } = await supabase.schema('pl').from('profiles').select('full_name,email').eq('id', user.id).single()
    const customerId = await getOrCreateStripeCustomer(user.id, user.email!, profile?.full_name || undefined)

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/settings/billing?success=true`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/settings/billing`,
      metadata: { user_id: user.id, plan_id: planId },
      subscription_data: {
        metadata: { user_id: user.id, plan_id: planId },
        trial_period_days: undefined,
      },
      allow_promotion_codes: true,
    })

    return NextResponse.json({ url: session.url })
  } catch (err: unknown) {
    console.error('Stripe checkout error:', err)
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}
