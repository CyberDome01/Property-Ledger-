import { NextRequest, NextResponse } from 'next/server'
import { stripe, getPlanFromPriceId } from '@/lib/stripe'
import { createAdminClient } from '@/lib/supabase/server'
import type Stripe from 'stripe'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature')!

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err) {
    console.error('Webhook signature error:', err)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  const supabase = createAdminClient()

  async function updateSubscription(sub: Stripe.Subscription) {
    const userId = sub.metadata?.user_id
    if (!userId) return

    const priceId = sub.items.data[0]?.price?.id
    const plan = getPlanFromPriceId(priceId)

    await supabase.schema('pl').from('subscriptions').upsert({
      user_id: userId,
      stripe_customer_id: sub.customer as string,
      stripe_subscription_id: sub.id,
      plan,
      status: sub.status as string,
      current_period_end: new Date((sub as any).current_period_end * 1000).toISOString(),
      cancel_at_period_end: sub.cancel_at_period_end,
    }, { onConflict: 'user_id' })
  }

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session
      if (session.mode === 'subscription') {
        const sub = await stripe.subscriptions.retrieve(session.subscription as string)
        await updateSubscription(sub)
      }
      break
    }
    case 'customer.subscription.updated':
    case 'customer.subscription.created': {
      await updateSubscription(event.data.object as Stripe.Subscription)
      break
    }
    case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription
      const userId = sub.metadata?.user_id
      if (userId) {
        await supabase.schema('pl').from('subscriptions').update({
          status: 'canceled',
          plan: 'trial',
          stripe_subscription_id: null,
        }).eq('user_id', userId)
      }
      break
    }
    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice
      const subId = (invoice as any).subscription as string
      if (subId) {
        const sub = await stripe.subscriptions.retrieve(subId)
        await updateSubscription(sub)
      }
      break
    }
  }

  return NextResponse.json({ received: true })
}
