import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const year = searchParams.get('year')
  const propertyId = searchParams.get('property_id')

  let query = supabase.schema('pl').from('transactions')
    .select('*, properties:pl.properties(name)')
    .eq('user_id', user.id)
    .order('date', { ascending: false })

  if (year) {
    query = query.gte('date', `${year}-01-01`).lte('date', `${year}-12-31`)
  }
  if (propertyId) {
    query = query.eq('property_id', propertyId)
  }

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  const rows = [
    ['Date', 'Property', 'Type', 'Category', 'Description', 'Vendor', 'Amount'].join(','),
    ...(data || []).map((t) => [
      t.date,
      `"${(t.properties as any)?.name || ''}"`,
      t.type,
      `"${t.category}"`,
      `"${t.description || ''}"`,
      `"${t.vendor || ''}"`,
      Number(t.amount).toFixed(2),
    ].join(',')),
  ].join('\n')

  const filename = `transactions${year ? `-${year}` : ''}.csv`
  return new NextResponse(rows, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="${filename}"`,
    },
  })
}
