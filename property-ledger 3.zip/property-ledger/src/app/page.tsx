import Link from 'next/link'
import { PLANS } from '@/lib/constants'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="border-b border-gray-100 sticky top-0 bg-white/90 backdrop-blur-sm z-50">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-brand-600 rounded-lg flex items-center justify-center">
              <span className="text-white text-xs font-bold">PL</span>
            </div>
            <span className="font-semibold text-gray-900">PropertyLedger</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/login" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Sign in
            </Link>
            <Link
              href="/signup"
              className="h-8 px-4 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-700 transition-colors inline-flex items-center"
            >
              Start free trial
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-24 pb-20 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-brand-50 border border-brand-200 rounded-full text-xs font-medium text-brand-700 mb-8">
          Launch pricing — lock in your rate before prices increase
        </div>
        <h1 className="text-5xl font-bold text-gray-900 tracking-tight leading-tight mb-6">
          Rental property accounting<br />
          <span className="text-brand-600">done right</span>
        </h1>
        <p className="text-xl text-gray-500 max-w-2xl mx-auto mb-10 leading-relaxed">
          Track rental income and expenses, then generate Schedule E tax reports in minutes — not hours.
          No banking products. No hidden agenda. Just clean accounting.
        </p>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <Link
            href="/signup"
            className="h-12 px-8 bg-gray-900 text-white font-semibold rounded-xl hover:bg-gray-700 transition-colors inline-flex items-center text-base"
          >
            Start your 14-day free trial
          </Link>
          <Link
            href="#pricing"
            className="h-12 px-8 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition-colors inline-flex items-center text-base"
          >
            View pricing
          </Link>
        </div>
        <p className="text-sm text-gray-400 mt-4">No credit card required. 14-day free trial included.</p>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 py-20 border-t border-gray-100">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Everything a landlord needs</h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            Purpose-built for rental property owners — not a generic accounting tool with a real estate skin.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              title: 'Schedule E in one click',
              description:
                'Generate IRS-formatted Schedule E reports property by property. Every line item pre-mapped to the correct tax category. Your CPA will thank you.',
            },
            {
              title: 'Depreciation calculator',
              description:
                'Automatic straight-line depreciation using IRS mid-month convention. 27.5-year residential, 39-year commercial. Always deduct the right amount.',
            },
            {
              title: 'Lease & tenant tracking',
              description:
                'Track active leases, expiration dates, security deposits, and tenant contact info. Get alerts 90 days before a lease expires.',
            },
            {
              title: 'Recurring transactions',
              description:
                'Set up monthly rent, insurance, or mortgage interest once. Stop entering the same transactions every month manually.',
            },
            {
              title: 'CSV export',
              description:
                'Download your transactions or full Schedule E as a spreadsheet any time. Tax prep, accountant sharing, or your own records.',
            },
            {
              title: 'Occupancy tracking',
              description:
                'See exactly which units are occupied, vacant, or expiring soon. Monitor your portfolio occupancy rate across all properties.',
            },
          ].map((f) => (
            <div key={f.title} className="border border-gray-200 rounded-xl p-6 hover:border-brand-300 transition-colors">
              <h3 className="font-semibold text-gray-900 mb-2">{f.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{f.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="max-w-6xl mx-auto px-6 py-20 border-t border-gray-100">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Simple, transparent pricing</h2>
          <p className="text-gray-500">No per-transaction fees. No banking upsells. Every plan includes a 14-day free trial.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PLANS.map((plan, i) => (
            <div
              key={plan.id}
              className={`rounded-2xl p-8 border-2 flex flex-col ${
                i === 1
                  ? 'border-brand-500 bg-brand-50 relative'
                  : 'border-gray-200 bg-white'
              }`}
            >
              {i === 1 && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-brand-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
                  Most popular
                </div>
              )}
              <div className="mb-6">
                <div className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">{plan.name}</div>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-gray-900">${plan.annualPrice}</span>
                  <span className="text-gray-400 text-sm">/mo billed annually</span>
                </div>
                <div className="text-xs text-gray-400 mt-1">or ${plan.monthlyPrice}/mo month-to-month</div>
              </div>
              <ul className="space-y-3 flex-1 mb-8">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-gray-600">
                    <svg className="w-4 h-4 text-brand-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href="/signup"
                className={`w-full h-11 rounded-xl font-semibold text-sm flex items-center justify-center transition-colors ${
                  i === 1
                    ? 'bg-brand-600 text-white hover:bg-brand-700'
                    : 'bg-gray-900 text-white hover:bg-gray-700'
                }`}
              >
                Start free trial
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-100 py-10">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between text-sm text-gray-400">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-brand-600 rounded flex items-center justify-center">
              <span className="text-white text-xs font-bold">PL</span>
            </div>
            <span>PropertyLedger</span>
          </div>
          <span>Built for landlords, by people who do the books.</span>
        </div>
      </footer>
    </div>
  )
}
