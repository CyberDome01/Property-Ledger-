import { createClient } from '@/lib/supabase/server'
import ScheduleEClient from '@/components/reports/schedule-e-client'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Schedule E' }

export default async function ScheduleEPage({ searchParams }: { searchParams: { year?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const [{ data: properties }, { data: transactions }] = await Promise.all([
    supabase.schema('pl').from('properties').select('*').eq('user_id', user.id).order('name'),
    supabase.schema('pl').from('transactions')
      .select('*').eq('user_id', user.id).order('date', { ascending: false }),
  ])

  return (
    <ScheduleEClient
      properties={properties || []}
      allTransactions={transactions || []}
      defaultYear={parseInt(searchParams.year || String(new Date().getFullYear() - 1))}
    />
  )
}
