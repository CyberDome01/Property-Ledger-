import { createClient } from '@/lib/supabase/server'
import ReportsClient from '@/components/reports/reports-client'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Reports' }

export default async function ReportsPage({ searchParams }: { searchParams: { year?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const year = parseInt(searchParams.year || String(new Date().getFullYear()))

  const [{ data: properties }, { data: transactions }, { data: leases }] = await Promise.all([
    supabase.schema('pl').from('properties').select('*').eq('user_id', user.id).order('name'),
    supabase.schema('pl').from('transactions')
      .select('*').eq('user_id', user.id).order('date', { ascending: true }),
    supabase.schema('pl').from('leases')
      .select('*, properties:pl.properties(id,name)').eq('user_id', user.id),
  ])

  return (
    <ReportsClient
      properties={properties || []}
      allTransactions={transactions || []}
      allLeases={leases || []}
      defaultYear={year}
    />
  )
}
