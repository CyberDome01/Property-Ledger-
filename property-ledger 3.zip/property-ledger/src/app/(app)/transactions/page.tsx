import { createClient } from '@/lib/supabase/server'
import TransactionsClient from '@/components/transactions/transactions-client'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Transactions' }

export default async function TransactionsPage({ searchParams }: { searchParams: { action?: string; year?: string; property?: string; type?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const [{ data: properties }, { data: transactions }] = await Promise.all([
    supabase.schema('pl').from('properties').select('id,name').eq('user_id', user.id).order('name'),
    supabase.schema('pl').from('transactions')
      .select('*, properties:pl.properties(id,name)')
      .eq('user_id', user.id)
      .order('date', { ascending: false })
      .order('created_at', { ascending: false }),
  ])

  return (
    <TransactionsClient
      properties={properties || []}
      initialTransactions={transactions || []}
      showForm={searchParams.action === 'new'}
    />
  )
}
