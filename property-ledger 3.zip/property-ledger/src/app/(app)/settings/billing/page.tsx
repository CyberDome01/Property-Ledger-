import { createClient } from '@/lib/supabase/server'
import BillingClient from '@/components/billing/billing-client'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Billing & Plan' }

export default async function BillingPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const { data: subscription } = await supabase
    .schema('pl').from('subscriptions').select('*').eq('user_id', user.id).single()

  return <BillingClient subscription={subscription} userEmail={user.email || ''} />
}
