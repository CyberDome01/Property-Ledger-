import { createClient } from '@/lib/supabase/server'
import { formatCurrency, formatDate } from '@/lib/utils'
import { calculateDepreciation } from '@/lib/depreciation'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import DeletePropertyButton from '@/components/properties/delete-property-button'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Property' }

export default async function PropertyDetailPage({
  params,
  searchParams,
}: {
  params: { id: string }
  searchParams: { year?: string }
}) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const year = parseInt(searchParams.year || String(new Date().getFullYear()))

  const [{ data: property }, { data: transactions }, { data: leases }] = await Promise.all([
    supabase.schema('pl').from('properties').select('*').eq('id', params.id).eq('user_id', user.id).single(),
    supabase.schema('pl').from('transactions')
      .select('*').eq('property_id', params.id).eq('user_id', user.id).order('date', { ascending: false }),
    supabase.schema('pl').from('leases')
      .select('*').eq('property_id', params.id).eq('user_id', user.id).order('start_date', { ascending: false }),
  ])

  if (!property) notFound()

  const yearTxns = (transactions || []).filter((t) => t.date.startsWith(String(year)))
  const income = yearTxns.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0)
  const expenses = yearTxns.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0)
  const net = income - expenses
  const dep = calculateDepreciation(property, year)
  const activeLease = (leases || []).find((l) => l.is_active)

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="flex items-center gap-2 text-sm text-gray-400 mb-1">
            <Link href="/properties" className="hover:text-gray-600">Properties</Link>
            <span>/</span>
            <span className="text-gray-600">{property.name}</span>
          </div>
          <h1>{property.name}</h1>
          <p className="text-sm text-gray-500 mt-0.5">{property.address}{property.city ? `, ${property.city}` : ''}{property.state_province ? `, ${property.state_province}` : ''}</p>
        </div>
        <div className="flex items-center gap-2">
          <select className="select w-28" defaultValue={year}>
            {[2026, 2025, 2024, 2023].map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
          <DeletePropertyButton propertyId={property.id} />
        </div>
      </div>

      {/* Property details */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="metric-card">
          <p className="text-xs text-gray-500">Income {year}</p>
          <p className="text-2xl font-semibold text-emerald-600">{formatCurrency(income)}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs text-gray-500">Expenses {year}</p>
          <p className="text-2xl font-semibold text-red-500">{formatCurrency(expenses)}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs text-gray-500">Net income {year}</p>
          <p className={`text-2xl font-semibold ${net >= 0 ? 'text-gray-900' : 'text-red-500'}`}>
            {net < 0 ? '-' : ''}{formatCurrency(Math.abs(net))}
          </p>
        </div>
        <div className="metric-card">
          <p className="text-xs text-gray-500">Monthly rent</p>
          <p className="text-2xl font-semibold">{property.monthly_rent > 0 ? formatCurrency(Number(property.monthly_rent)) : '—'}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-5">
          {/* Transactions */}
          <div className="card overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <h3>Transactions — {year}</h3>
              <Link href={`/transactions?action=new&property=${property.id}`} className="text-xs text-brand-600 font-medium hover:underline">Add</Link>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="text-left px-5 py-2.5 text-xs font-semibold text-gray-400 uppercase tracking-wider">Date</th>
                  <th className="text-left px-5 py-2.5 text-xs font-semibold text-gray-400 uppercase tracking-wider">Category</th>
                  <th className="text-left px-5 py-2.5 text-xs font-semibold text-gray-400 uppercase tracking-wider hidden md:table-cell">Description</th>
                  <th className="text-right px-5 py-2.5 text-xs font-semibold text-gray-400 uppercase tracking-wider">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {yearTxns.length === 0 ? (
                  <tr><td colSpan={4} className="px-5 py-6 text-center text-sm text-gray-400">No transactions for {year}.</td></tr>
                ) : yearTxns.map((t) => (
                  <tr key={t.id} className="table-row-hover">
                    <td className="px-5 py-2.5 text-gray-500 whitespace-nowrap">{formatDate(t.date)}</td>
                    <td className="px-5 py-2.5">
                      <span className={t.type === 'income' ? 'badge-income' : 'badge-expense'}>{t.category}</span>
                    </td>
                    <td className="px-5 py-2.5 text-gray-400 hidden md:table-cell max-w-xs truncate">{t.description || '—'}</td>
                    <td className={`px-5 py-2.5 text-right font-semibold whitespace-nowrap ${t.type === 'income' ? 'text-emerald-600' : 'text-red-500'}`}>
                      {t.type === 'income' ? '+' : '-'}{formatCurrency(Number(t.amount))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-5">
          {/* Property info */}
          <div className="card p-5">
            <h3 className="mb-3">Details</h3>
            <dl className="space-y-2 text-sm">
              {[
                ['Type', property.property_type],
                ['Bedrooms', property.bedrooms],
                ['Bathrooms', property.bathrooms],
                ['Square feet', property.square_feet ? property.square_feet.toLocaleString() : null],
                ['Purchase price', property.purchase_price ? formatCurrency(Number(property.purchase_price)) : null],
                ['Purchase date', property.purchase_date ? formatDate(property.purchase_date) : null],
                ['Country', property.country],
              ].map(([label, value]) => value ? (
                <div key={String(label)} className="flex justify-between gap-2">
                  <dt className="text-gray-400">{label}</dt>
                  <dd className="font-medium text-right">{value}</dd>
                </div>
              ) : null)}
            </dl>
          </div>

          {/* Depreciation */}
          {dep && (
            <div className="card p-5">
              <h3 className="mb-3">Depreciation — {year}</h3>
              <dl className="space-y-2 text-sm">
                {[
                  ['Annual deduction', formatCurrency(dep.annualDepreciation)],
                  ['Depreciable basis', formatCurrency(dep.depreciableBasis)],
                  ['Land value', formatCurrency(dep.landValue)],
                  ['Accumulated', formatCurrency(dep.accumulatedDepreciation)],
                  ['Remaining basis', formatCurrency(dep.remainingBasis)],
                  ['Schedule', `${dep.totalYears}-year straight-line`],
                ].map(([label, value]) => (
                  <div key={String(label)} className="flex justify-between gap-2">
                    <dt className="text-gray-400">{label}</dt>
                    <dd className="font-medium text-right">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          {/* Active lease */}
          {activeLease && (
            <div className="card p-5">
              <h3 className="mb-3">Current lease</h3>
              <dl className="space-y-2 text-sm">
                {[
                  ['Tenant', activeLease.tenant_name],
                  ['Rent', formatCurrency(Number(activeLease.monthly_rent)) + '/mo'],
                  ['Deposit', formatCurrency(Number(activeLease.security_deposit))],
                  ['Start', formatDate(activeLease.start_date)],
                  ['End', activeLease.end_date ? formatDate(activeLease.end_date) : 'Month-to-month'],
                  activeLease.tenant_email ? ['Email', activeLease.tenant_email] : null,
                  activeLease.tenant_phone ? ['Phone', activeLease.tenant_phone] : null,
                ].filter(Boolean).map((row) => row && (
                  <div key={row[0]} className="flex justify-between gap-2">
                    <dt className="text-gray-400">{row[0]}</dt>
                    <dd className="font-medium text-right truncate max-w-[160px]">{row[1]}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
