import { createClient } from '@/lib/supabase/server'
import { formatCurrency } from '@/lib/utils'
import Link from 'next/link'
import PropertyForm from '@/components/properties/property-form'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Properties' }

export default async function PropertiesPage({ searchParams }: { searchParams: { action?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const year = new Date().getFullYear()

  const [{ data: properties }, { data: transactions }, { data: leases }] = await Promise.all([
    supabase.schema('pl').from('properties').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
    supabase.schema('pl').from('transactions')
      .select('property_id,type,amount')
      .eq('user_id', user.id)
      .gte('date', `${year}-01-01`)
      .lte('date', `${year}-12-31`),
    supabase.schema('pl').from('leases').select('property_id,is_active').eq('user_id', user.id),
  ])

  const props = properties || []
  const txns = transactions || []
  const allLeases = leases || []

  function getStats(propertyId: string) {
    const pt = txns.filter((t) => t.property_id === propertyId)
    const income = pt.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0)
    const expenses = pt.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0)
    const activeLease = allLeases.some((l) => l.property_id === propertyId && l.is_active)
    return { income, expenses, net: income - expenses, activeLease }
  }

  const showForm = searchParams.action === 'new'

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Properties</h1>
          <p className="text-sm text-gray-500 mt-0.5">{props.length} propert{props.length === 1 ? 'y' : 'ies'} tracked</p>
        </div>
        <Link href="/properties?action=new" className="h-9 px-4 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-700 transition-colors inline-flex items-center">
          Add property
        </Link>
      </div>

      {showForm && <PropertyForm />}

      {props.length === 0 && !showForm ? (
        <div className="card p-12 text-center">
          <p className="text-gray-500 mb-4">Add your first rental property to get started.</p>
          <Link href="/properties?action=new" className="h-9 px-6 bg-brand-600 text-white text-sm font-medium rounded-lg hover:bg-brand-700 transition-colors inline-flex items-center">
            Add property
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {props.map((p) => {
            const { income, expenses, net, activeLease } = getStats(p.id)
            return (
              <Link key={p.id} href={`/properties/${p.id}`} className="card p-5 hover:border-brand-300 transition-colors block group">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="group-hover:text-brand-700 transition-colors">{p.name}</h3>
                    <p className="text-xs text-gray-400 mt-0.5">{p.address}{p.city ? `, ${p.city}` : ''}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${activeLease ? 'bg-emerald-400' : 'bg-gray-300'}`} />
                    <span className="text-xs text-gray-400">{activeLease ? 'Occupied' : 'Vacant'}</span>
                  </div>
                </div>
                <div className="text-xs text-gray-400 mb-4 flex items-center gap-3">
                  <span>{p.property_type}</span>
                  {p.monthly_rent > 0 && <span>{formatCurrency(Number(p.monthly_rent))}/mo</span>}
                  {p.bedrooms && <span>{p.bedrooms}bd</span>}
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-gray-50 rounded-lg p-2.5">
                    <p className="text-xs text-gray-400">Income</p>
                    <p className="text-sm font-semibold text-emerald-600">{formatCurrency(income)}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-2.5">
                    <p className="text-xs text-gray-400">Expenses</p>
                    <p className="text-sm font-semibold text-red-500">{formatCurrency(expenses)}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-2.5">
                    <p className="text-xs text-gray-400">Net {year}</p>
                    <p className={`text-sm font-semibold ${net >= 0 ? 'text-gray-900' : 'text-red-500'}`}>
                      {net < 0 ? '-' : ''}{formatCurrency(Math.abs(net))}
                    </p>
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
      )}
    </div>
  )
}
