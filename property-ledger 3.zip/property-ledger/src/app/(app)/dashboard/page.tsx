import { createClient } from '@/lib/supabase/server'
import { formatCurrency } from '@/lib/utils'
import DashboardCharts from '@/components/dashboard/charts'
import RecentTransactions from '@/components/dashboard/recent-transactions'
import LeaseAlerts from '@/components/dashboard/lease-alerts'
import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = { title: 'Dashboard' }

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: { year?: string }
}) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const year = parseInt(searchParams.year || String(new Date().getFullYear()))

  const [{ data: properties }, { data: transactions }, { data: leases }] = await Promise.all([
    supabase.schema('pl').from('properties').select('id,name,monthly_rent,is_active').eq('user_id', user.id),
    supabase.schema('pl').from('transactions')
      .select('id,date,type,category,amount,property_id,description')
      .eq('user_id', user.id)
      .gte('date', `${year}-01-01`)
      .lte('date', `${year}-12-31`)
      .order('date', { ascending: false }),
    supabase.schema('pl').from('leases')
      .select('id,tenant_name,end_date,property_id,properties:pl.properties(name)')
      .eq('user_id', user.id)
      .eq('is_active', true),
  ])

  const txns = transactions || []
  const props = properties || []
  const activeLeases = leases || []

  const totalIncome = txns.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0)
  const totalExpenses = txns.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0)
  const netIncome = totalIncome - totalExpenses
  const activeProperties = props.filter((p) => p.is_active).length

  // Leases expiring in 90 days
  const in90Days = new Date(); in90Days.setDate(in90Days.getDate() + 90)
  const expiringLeases = activeLeases.filter((l) => l.end_date && new Date(l.end_date) <= in90Days)

  // Monthly data for chart
  const months = Array.from({ length: 12 }, (_, i) => {
    const m = String(i + 1).padStart(2, '0')
    const monthTxns = txns.filter((t) => t.date.startsWith(`${year}-${m}`))
    return {
      month: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][i],
      income: monthTxns.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0),
      expenses: monthTxns.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0),
    }
  })

  const recentTxns = txns.slice(0, 8)

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p className="text-sm text-gray-500 mt-0.5">Overview for {year}</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            className="select w-28"
            defaultValue={year}
            onChange={undefined}
          >
            {[2026, 2025, 2024, 2023].map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
          <Link href="/transactions?action=new" className="h-9 px-4 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-700 transition-colors inline-flex items-center gap-2">
            Add transaction
          </Link>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="metric-card">
          <p className="text-xs font-medium text-gray-500 mb-1">Rental income</p>
          <p className="text-2xl font-semibold text-emerald-600">{formatCurrency(totalIncome)}</p>
          <p className="text-xs text-gray-400 mt-0.5">{year}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs font-medium text-gray-500 mb-1">Total expenses</p>
          <p className="text-2xl font-semibold text-red-500">{formatCurrency(totalExpenses)}</p>
          <p className="text-xs text-gray-400 mt-0.5">{year}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs font-medium text-gray-500 mb-1">Net income</p>
          <p className={`text-2xl font-semibold ${netIncome >= 0 ? 'text-gray-900' : 'text-red-500'}`}>
            {netIncome < 0 ? '-' : ''}{formatCurrency(Math.abs(netIncome))}
          </p>
          <p className="text-xs text-gray-400 mt-0.5">Income – expenses</p>
        </div>
        <div className="metric-card">
          <p className="text-xs font-medium text-gray-500 mb-1">Active properties</p>
          <p className="text-2xl font-semibold text-gray-900">{activeProperties}</p>
          <p className="text-xs text-gray-400 mt-0.5">{activeLeases.length} active lease{activeLeases.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      {/* Chart */}
      <div className="card p-5 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3>Monthly overview — {year}</h3>
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-emerald-500 inline-block" />Income
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-red-400 inline-block" />Expenses
            </span>
          </div>
        </div>
        <DashboardCharts data={months} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3>Recent transactions</h3>
            <Link href="/transactions" className="text-xs text-brand-600 font-medium hover:underline">View all</Link>
          </div>
          <RecentTransactions transactions={recentTxns} properties={props} />
        </div>

        <div className="card">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3>Lease alerts</h3>
            <Link href="/leases" className="text-xs text-brand-600 font-medium hover:underline">View all</Link>
          </div>
          <LeaseAlerts leases={expiringLeases} allLeases={activeLeases} />
        </div>
      </div>
    </div>
  )
}
