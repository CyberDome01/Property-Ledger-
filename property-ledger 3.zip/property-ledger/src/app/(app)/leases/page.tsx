import { createClient } from '@/lib/supabase/server'
import LeasesClient from '@/components/leases/leases-client'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Leases' }

export default async function LeasesPage({ searchParams }: { searchParams: { action?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const [{ data: properties }, { data: leases }] = await Promise.all([
    supabase.schema('pl').from('properties').select('id,name').eq('user_id', user.id).eq('is_active', true).order('name'),
    supabase.schema('pl').from('leases')
      .select('*, properties:pl.properties(id,name,address)')
      .eq('user_id', user.id)
      .order('end_date', { ascending: true }),
  ])

  return <LeasesClient properties={properties || []} initialLeases={leases || []} showForm={searchParams.action === 'new'} />
}
