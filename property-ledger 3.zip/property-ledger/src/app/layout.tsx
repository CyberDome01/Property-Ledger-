import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-geist-sans',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: 'PropertyLedger — Rental Property Accounting',
    template: '%s | PropertyLedger',
  },
  description:
    'Track rental income and expenses, generate Schedule E tax reports in minutes. Clean rental accounting — no banking products, no hidden agenda.',
  keywords: ['rental property accounting', 'Schedule E', 'landlord software', 'rental income tracker'],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body>{children}</body>
    </html>
  )
}
