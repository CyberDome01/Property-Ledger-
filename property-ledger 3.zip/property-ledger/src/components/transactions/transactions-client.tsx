'use client'

import { useState, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { formatCurrency, formatDate } from '@/lib/utils'
import { INCOME_CATEGORIES, EXPENSE_CATEGORIES } from '@/lib/constants'
import Papa from 'papaparse'

interface Property { id: string; name: string }
interface Transaction {
  id: string; date: string; type: string; category: string; description: string | null
  amount: number; property_id: string | null; vendor: string | null; is_recurring: boolean
  properties?: { id: string; name: string } | null
}

interface Props {
  properties: Property[]
  initialTransactions: Transaction[]
  showForm: boolean
}

export default function TransactionsClient({ properties, initialTransactions, showForm: initShowForm }: Props) {
  const router = useRouter()
  const supabase = createClient()

  const [txns, setTxns] = useState(initialTransactions)
  const [showForm, setShowForm] = useState(initShowForm)
  const [filterYear, setFilterYear] = useState('all')
  const [filterProp, setFilterProp] = useState('all')
  const [filterType, setFilterType] = useState('all')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [txnType, setTxnType] = useState<'income' | 'expense'>('income')

  const filtered = useMemo(() => txns.filter((t) => {
    if (filterYear !== 'all' && !t.date.startsWith(filterYear)) return false
    if (filterProp !== 'all' && t.property_id !== filterProp) return false
    if (filterType !== 'all' && t.type !== filterType) return false
    return true
  }), [txns, filterYear, filterProp, filterType])

  const totalIncome = filtered.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0)
  const totalExpenses = filtered.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0)

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(''); setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const fd = new FormData(e.currentTarget)
    const payload = {
      user_id: user.id,
      date: fd.get('date') as string,
      type: fd.get('type') as string,
      property_id: fd.get('property_id') as string || null,
      category: fd.get('category') as string,
      description: fd.get('description') as string || null,
      vendor: fd.get('vendor') as string || null,
      amount: parseFloat(fd.get('amount') as string),
      is_recurring: fd.get('is_recurring') === 'on',
      recurring_frequency: fd.get('recurring_frequency') as string || null,
    }
    if (!payload.date || isNaN(payload.amount)) { setError('Date and amount are required'); setLoading(false); return }
    const { data, error } = await supabase.schema('pl').from('transactions').insert(payload).select('*, properties:pl.properties(id,name)').single()
    if (error) { setError(error.message); setLoading(false); return }
    setTxns((prev) => [data, ...prev])
    setShowForm(false)
    setLoading(false)
    ;(e.target as HTMLFormElement).reset()
  }

  async function deleteTxn(id: string) {
    if (!confirm('Delete this transaction?')) return
    await supabase.schema('pl').from('transactions').delete().eq('id', id)
    setTxns((prev) => prev.filter((t) => t.id !== id))
  }

  function exportCSV() {
    const rows = filtered.map((t) => ({
      Date: t.date,
      Property: t.properties?.name || '',
      Type: t.type,
      Category: t.category,
      Description: t.description || '',
      Vendor: t.vendor || '',
      Amount: Number(t.amount).toFixed(2),
    }))
    const csv = Papa.unparse(rows)
    const blob = new Blob([csv], { type: 'text/csv' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob)
    a.download = `transactions-${filterYear === 'all' ? 'all' : filterYear}.csv`; a.click()
  }

  const years = [2026, 2025, 2024, 2023]
  const cats = txnType === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Transactions</h1>
          <p className="text-sm text-gray-500 mt-0.5">{filtered.length} transactions</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={exportCSV}>Export CSV</Button>
          <Button size="sm" onClick={() => setShowForm(!showForm)}>
            {showForm ? 'Close' : 'Add transaction'}
          </Button>
        </div>
      </div>

      {/* Summary bar */}
      <div className="grid grid-cols-3 gap-4 mb-5">
        <div className="metric-card">
          <p className="text-xs text-gray-500">Income</p>
          <p className="text-lg font-semibold text-emerald-600">{formatCurrency(totalIncome)}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs text-gray-500">Expenses</p>
          <p className="text-lg font-semibold text-red-500">{formatCurrency(totalExpenses)}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs text-gray-500">Net</p>
          <p className={`text-lg font-semibold ${totalIncome - totalExpenses >= 0 ? 'text-gray-900' : 'text-red-500'}`}>
            {formatCurrency(Math.abs(totalIncome - totalExpenses))}
          </p>
        </div>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="card p-5 mb-5">
          <h3 className="mb-4">Add transaction</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="label">Date *</label>
                <input name="date" type="date" className="input" defaultValue={new Date().toISOString().split('T')[0]} required />
              </div>
              <div>
                <label className="label">Type *</label>
                <select name="type" className="select" value={txnType} onChange={(e) => setTxnType(e.target.value as 'income' | 'expense')}>
                  <option value="income">Income</option>
                  <option value="expense">Expense</option>
                </select>
              </div>
              <div>
                <label className="label">Property</label>
                <select name="property_id" className="select">
                  <option value="">All properties</option>
                  {properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Amount ($) *</label>
                <input name="amount" type="number" step="0.01" min="0.01" className="input" placeholder="0.00" required />
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="label">Category *</label>
                <select name="category" className="select" required>
                  {cats.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Description</label>
                <input name="description" className="input" placeholder="Optional notes" />
              </div>
              <div>
                <label className="label">Vendor / Payee</label>
                <input name="vendor" className="input" placeholder="Optional" />
              </div>
              <div className="flex flex-col justify-end gap-2">
                <label className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                  <input name="is_recurring" type="checkbox" className="rounded" />
                  Recurring
                </label>
                <select name="recurring_frequency" className="select text-xs">
                  <option value="">Frequency</option>
                  <option value="monthly">Monthly</option>
                  <option value="quarterly">Quarterly</option>
                  <option value="annually">Annually</option>
                </select>
              </div>
            </div>
            {error && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</p>}
            <div className="flex gap-3">
              <Button type="submit" loading={loading}>Save</Button>
              <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <select className="select w-32" value={filterYear} onChange={(e) => setFilterYear(e.target.value)}>
          <option value="all">All years</option>
          {years.map((y) => <option key={y} value={String(y)}>{y}</option>)}
        </select>
        <select className="select w-44" value={filterProp} onChange={(e) => setFilterProp(e.target.value)}>
          <option value="all">All properties</option>
          {properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <select className="select w-36" value={filterType} onChange={(e) => setFilterType(e.target.value)}>
          <option value="all">All types</option>
          <option value="income">Income only</option>
          <option value="expense">Expenses only</option>
        </select>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Property</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Category</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider hidden md:table-cell">Description</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-sm text-gray-400">
                  No transactions found for these filters.
                </td>
              </tr>
            ) : filtered.map((t) => (
              <tr key={t.id} className="table-row-hover">
                <td className="px-4 py-3 text-gray-500 whitespace-nowrap">{formatDate(t.date)}</td>
                <td className="px-4 py-3 text-gray-700">{t.properties?.name || <span className="text-gray-400">—</span>}</td>
                <td className="px-4 py-3">
                  <span className={t.type === 'income' ? 'badge-income' : 'badge-expense'}>{t.category}</span>
                </td>
                <td className="px-4 py-3 text-gray-400 hidden md:table-cell max-w-xs truncate">{t.description || '—'}</td>
                <td className={`px-4 py-3 text-right font-semibold whitespace-nowrap ${t.type === 'income' ? 'text-emerald-600' : 'text-red-500'}`}>
                  {t.type === 'income' ? '+' : '-'}{formatCurrency(Number(t.amount))}
                </td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => deleteTxn(t.id)} className="text-xs text-gray-300 hover:text-red-500 transition-colors font-medium">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
