'use client'

import { useState, useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from 'recharts'
import { formatCurrency } from '@/lib/utils'
import { calculateDepreciation } from '@/lib/depreciation'
import type { Property, Transaction } from '@/types'

const YEARS = [2026, 2025, 2024, 2023]
const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4', '#ec4899']

interface Lease {
  id: string; is_active: boolean; property_id: string
  properties?: { id: string; name: string } | null
}

interface Props {
  properties: Property[]
  allTransactions: Transaction[]
  allLeases: Lease[]
  defaultYear: number
}

export default function ReportsClient({ properties, allTransactions, allLeases, defaultYear }: Props) {
  const [year, setYear] = useState(defaultYear)

  const { byProperty, monthlyNet, expenseBreakdown } = useMemo(() => {
    const yearTxns = allTransactions.filter((t) => t.date.startsWith(String(year)))

    const byProperty = properties.map((p) => {
      const pt = yearTxns.filter((t) => t.property_id === p.id)
      const income = pt.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0)
      const expenses = pt.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0)
      return { name: p.name, income, expenses, net: income - expenses }
    })

    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    const monthlyNet = months.map((month, i) => {
      const m = String(i + 1).padStart(2, '0')
      const mt = yearTxns.filter((t) => t.date.startsWith(`${year}-${m}`))
      const income = mt.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0)
      const expenses = mt.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0)
      return { month, net: income - expenses, income, expenses }
    })

    const expMap: Record<string, number> = {}
    yearTxns.filter((t) => t.type === 'expense').forEach((t) => {
      expMap[t.category] = (expMap[t.category] || 0) + Number(t.amount)
    })
    const expenseBreakdown = Object.entries(expMap)
      .sort(([, a], [, b]) => b - a)
      .map(([name, value]) => ({ name, value }))

    return { byProperty, monthlyNet, expenseBreakdown }
  }, [properties, allTransactions, year])

  const occupiedCount = properties.filter((p) =>
    allLeases.some((l) => l.property_id === p.id && l.is_active)
  ).length
  const occupancyRate = properties.length > 0 ? Math.round((occupiedCount / properties.length) * 100) : 0

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Reports</h1>
          <p className="text-sm text-gray-500 mt-0.5">Portfolio analytics and financial summaries</p>
        </div>
        <select className="select w-28" value={year} onChange={(e) => setYear(parseInt(e.target.value))}>
          {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>

      {/* Occupancy */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="metric-card">
          <p className="text-xs text-gray-500">Properties</p>
          <p className="text-2xl font-semibold">{properties.length}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs text-gray-500">Occupied</p>
          <p className="text-2xl font-semibold text-emerald-600">{occupiedCount}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs text-gray-500">Vacant</p>
          <p className="text-2xl font-semibold text-amber-500">{properties.length - occupiedCount}</p>
        </div>
        <div className="metric-card">
          <p className="text-xs text-gray-500">Occupancy rate</p>
          <p className="text-2xl font-semibold">{occupancyRate}%</p>
        </div>
      </div>

      {/* Net income by month */}
      <div className="card p-5 mb-6">
        <h3 className="mb-4">Monthly cash flow — {year}</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={monthlyNet} margin={{ top: 4, right: 4, left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <YAxis tickFormatter={(v) => v >= 1000 ? `$${(v/1000).toFixed(0)}k` : `$${v}`} tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <Tooltip formatter={(v: number) => [`$${Number(v).toLocaleString()}`, '']} contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb' }} cursor={{ fill: 'rgba(0,0,0,0.03)' }} />
            <Bar dataKey="net" fill="#10b981" radius={[3, 3, 0, 0]} maxBarSize={30}
              label={false}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Income by property */}
        <div className="card p-5">
          <h3 className="mb-4">Income by property — {year}</h3>
          {byProperty.length === 0 ? (
            <p className="text-sm text-gray-400">No data yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={byProperty} layout="vertical" margin={{ top: 0, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false} />
                <XAxis type="number" tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#6b7280' }} axisLine={false} tickLine={false} width={90} />
                <Tooltip formatter={(v: number, k: string) => [`$${Number(v).toLocaleString()}`, k === 'income' ? 'Income' : k === 'expenses' ? 'Expenses' : 'Net']} contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb' }} />
                <Bar dataKey="income" fill="#10b981" radius={[0, 3, 3, 0]} maxBarSize={20} />
                <Bar dataKey="expenses" fill="#f87171" radius={[0, 3, 3, 0]} maxBarSize={20} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Expense breakdown pie */}
        <div className="card p-5">
          <h3 className="mb-4">Expense breakdown — {year}</h3>
          {expenseBreakdown.length === 0 ? (
            <p className="text-sm text-gray-400">No expense data yet.</p>
          ) : (
            <div className="flex items-center gap-4">
              <PieChart width={140} height={140}>
                <Pie data={expenseBreakdown} cx={65} cy={65} innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={2}>
                  {expenseBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
              </PieChart>
              <div className="flex-1 space-y-1.5 overflow-hidden">
                {expenseBreakdown.slice(0, 7).map((item, i) => (
                  <div key={item.name} className="flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                      <span className="text-gray-600 truncate">{item.name}</span>
                    </div>
                    <span className="font-medium shrink-0">{formatCurrency(item.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Depreciation table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h3>Depreciation schedule — {year}</h3>
          <p className="text-xs text-gray-400 mt-0.5">Straight-line, IRS mid-month convention. Residential: 27.5 yrs · Commercial: 39 yrs</p>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Property</th>
              <th className="text-right px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Purchase price</th>
              <th className="text-right px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Depreciable basis</th>
              <th className="text-right px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">{year} depreciation</th>
              <th className="text-right px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Accumulated</th>
              <th className="text-right px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Remaining basis</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {properties.map((p) => {
              const dep = calculateDepreciation(p, year)
              if (!dep) return (
                <tr key={p.id}>
                  <td className="px-5 py-3 font-medium">{p.name}</td>
                  <td className="px-5 py-3 text-right text-gray-400" colSpan={5}>No purchase price/date set</td>
                </tr>
              )
              return (
                <tr key={p.id} className="table-row-hover">
                  <td className="px-5 py-3 font-medium">{p.name}</td>
                  <td className="px-5 py-3 text-right text-gray-600">{formatCurrency(Number(p.purchase_price))}</td>
                  <td className="px-5 py-3 text-right text-gray-600">{formatCurrency(dep.depreciableBasis)}</td>
                  <td className="px-5 py-3 text-right font-semibold text-red-500">{formatCurrency(dep.annualDepreciation)}</td>
                  <td className="px-5 py-3 text-right text-gray-600">{formatCurrency(dep.accumulatedDepreciation)}</td>
                  <td className="px-5 py-3 text-right text-gray-600">{formatCurrency(dep.remainingBasis)}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
