'use client'

import { useState, useMemo } from 'react'
import { Button } from '@/components/ui/button'
import { formatCurrency } from '@/lib/utils'
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '@/lib/constants'
import { calculateDepreciation } from '@/lib/depreciation'
import Papa from 'papaparse'
import type { Property, Transaction } from '@/types'

interface Props {
  properties: Property[]
  allTransactions: Transaction[]
  defaultYear: number
}

const YEARS = [2025, 2024, 2023, 2022]

export default function ScheduleEClient({ properties, allTransactions, defaultYear }: Props) {
  const [year, setYear] = useState(defaultYear)

  const data = useMemo(() => {
    const yearTxns = allTransactions.filter((t) => t.date.startsWith(String(year)))
    return properties.map((prop) => {
      const pt = yearTxns.filter((t) => t.property_id === prop.id)
      const incomeByCategory: Record<string, number> = {}
      const expenseByCategory: Record<string, number> = {}

      pt.forEach((t) => {
        if (t.type === 'income') {
          incomeByCategory[t.category] = (incomeByCategory[t.category] || 0) + Number(t.amount)
        } else {
          expenseByCategory[t.category] = (expenseByCategory[t.category] || 0) + Number(t.amount)
        }
      })

      // Auto-calculate depreciation if not manually entered
      if (!expenseByCategory['Depreciation']) {
        const dep = calculateDepreciation(prop, year)
        if (dep && dep.annualDepreciation > 0) {
          expenseByCategory['Depreciation'] = dep.annualDepreciation
        }
      }

      const totalIncome = Object.values(incomeByCategory).reduce((s, v) => s + v, 0)
      const totalExpenses = Object.values(expenseByCategory).reduce((s, v) => s + v, 0)
      const netIncome = totalIncome - totalExpenses

      return { prop, incomeByCategory, expenseByCategory, totalIncome, totalExpenses, netIncome }
    })
  }, [properties, allTransactions, year])

  const grandIncome = data.reduce((s, d) => s + d.totalIncome, 0)
  const grandExpenses = data.reduce((s, d) => s + d.totalExpenses, 0)
  const grandNet = grandIncome - grandExpenses

  function exportCSV() {
    const rows: Record<string, string | number>[] = []
    data.forEach(({ prop, incomeByCategory, expenseByCategory, totalIncome, totalExpenses, netIncome }) => {
      rows.push({ Property: prop.name, Address: prop.address, Line: 'A. Rents received', Amount: totalIncome })
      EXPENSE_CATEGORIES.forEach((cat) => {
        if (expenseByCategory[cat]) {
          rows.push({ Property: prop.name, Address: prop.address, Line: `B. ${cat}`, Amount: expenseByCategory[cat] })
        }
      })
      rows.push({ Property: prop.name, Address: prop.address, Line: 'Total expenses', Amount: totalExpenses })
      rows.push({ Property: prop.name, Address: prop.address, Line: 'Net income / (loss)', Amount: netIncome })
      rows.push({ Property: '', Address: '', Line: '', Amount: '' })
    })
    rows.push({ Property: 'TOTALS', Address: '', Line: 'Grand total rents', Amount: grandIncome })
    rows.push({ Property: 'TOTALS', Address: '', Line: 'Grand total expenses', Amount: grandExpenses })
    rows.push({ Property: 'TOTALS', Address: '', Line: 'Grand net income / (loss)', Amount: grandNet })
    const csv = Papa.unparse(rows)
    const blob = new Blob([csv], { type: 'text/csv' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob)
    a.download = `schedule-e-${year}.csv`; a.click()
  }

  function handlePrint() { window.print() }

  return (
    <div>
      <div className="page-header no-print">
        <div>
          <h1>Schedule E</h1>
          <p className="text-sm text-gray-500 mt-0.5">IRS Form 1040 — Supplemental Income and Loss, Part I</p>
        </div>
        <div className="flex items-center gap-3">
          <select className="select w-28" value={year} onChange={(e) => setYear(parseInt(e.target.value))}>
            {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
          <Button variant="outline" size="sm" onClick={exportCSV}>Export CSV</Button>
          <Button variant="outline" size="sm" onClick={handlePrint}>Print</Button>
        </div>
      </div>

      {/* Print header */}
      <div className="hidden print:block mb-6 pb-4 border-b-2 border-gray-900">
        <h2 className="text-lg font-bold">SCHEDULE E (Form 1040) — Supplemental Income and Loss</h2>
        <p className="text-sm">Part I: Income or Loss From Rental Real Estate and Royalties — Tax Year {year}</p>
      </div>

      {properties.length === 0 ? (
        <div className="card p-10 text-center">
          <p className="text-gray-400">Add properties and transactions to generate your Schedule E report.</p>
        </div>
      ) : (
        <>
          {data.map(({ prop, incomeByCategory, expenseByCategory, totalIncome, totalExpenses, netIncome }) => (
            <div key={prop.id} className="card mb-5 overflow-hidden">
              {/* Property header */}
              <div className="px-6 py-4 bg-gray-50 border-b border-gray-200 flex items-start justify-between gap-4">
                <div>
                  <h3>{prop.name}</h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {prop.address}{prop.city ? `, ${prop.city}` : ''}{prop.state_province ? `, ${prop.state_province}` : ''}
                    {' · '}{prop.property_type}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs text-gray-400">Tax year {year}</p>
                  {prop.monthly_rent > 0 && (
                    <p className="text-xs text-gray-400">{formatCurrency(Number(prop.monthly_rent))}/mo scheduled rent</p>
                  )}
                </div>
              </div>

              {totalIncome === 0 && totalExpenses === 0 ? (
                <div className="px-6 py-5 text-sm text-gray-400">No transactions recorded for {year}.</div>
              ) : (
                <div className="px-6 py-4">
                  {/* Part A — Income */}
                  <div className="mb-5">
                    <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">A — Rental income</div>
                    {INCOME_CATEGORIES.filter((c) => incomeByCategory[c]).map((cat) => (
                      <div key={cat} className="flex justify-between items-center py-1.5 border-b border-gray-50 text-sm">
                        <span className="text-gray-600 pl-4">{cat}</span>
                        <span className="font-medium text-emerald-600">{formatCurrency(incomeByCategory[cat])}</span>
                      </div>
                    ))}
                    <div className="flex justify-between items-center py-2 text-sm font-semibold border-t border-gray-200 mt-1">
                      <span>Total rents received (Line 3)</span>
                      <span className="text-emerald-600">{formatCurrency(totalIncome)}</span>
                    </div>
                  </div>

                  {/* Part B — Expenses */}
                  <div className="mb-5">
                    <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">B — Expenses</div>
                    {EXPENSE_CATEGORIES.map((cat, i) => {
                      const amt = expenseByCategory[cat]
                      if (!amt) return null
                      // IRS Schedule E line numbers
                      const lineNumbers: Record<string, string> = {
                        'Advertising': '5', 'Auto and travel': '6', 'Cleaning and maintenance': '7',
                        'Commissions': '8', 'Insurance': '9', 'Legal and professional fees': '10',
                        'Management fees': '11', 'Mortgage interest (banks)': '12', 'Other interest': '13',
                        'Repairs': '14', 'Supplies': '15', 'Taxes': '16', 'Utilities': '17',
                        'Depreciation': '18', 'Other expenses': '19',
                      }
                      return (
                        <div key={cat} className="flex justify-between items-center py-1.5 border-b border-gray-50 text-sm">
                          <span className="text-gray-600 pl-4">
                            <span className="text-gray-300 text-xs mr-2">Ln {lineNumbers[cat]}</span>
                            {cat}
                          </span>
                          <span className="font-medium text-red-500">{formatCurrency(amt)}</span>
                        </div>
                      )
                    })}
                    <div className="flex justify-between items-center py-2 text-sm font-semibold border-t border-gray-200 mt-1">
                      <span>Total expenses (Line 20)</span>
                      <span className="text-red-500">{formatCurrency(totalExpenses)}</span>
                    </div>
                  </div>

                  {/* Net */}
                  <div className={`flex justify-between items-center py-3 px-4 rounded-lg text-sm font-semibold ${netIncome >= 0 ? 'bg-emerald-50 border border-emerald-200' : 'bg-red-50 border border-red-200'}`}>
                    <span>Net income / (loss) — Line 21 / 22</span>
                    <span className={netIncome >= 0 ? 'text-emerald-700' : 'text-red-600'}>
                      {netIncome < 0 ? `(${formatCurrency(Math.abs(netIncome))})` : formatCurrency(netIncome)}
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* Grand totals */}
          <div className="card p-6 bg-gray-50">
            <h3 className="mb-4">Schedule E summary — {year}</h3>
            <div className="space-y-2 text-sm max-w-sm">
              <div className="flex justify-between py-1.5 border-b border-gray-200">
                <span className="text-gray-600">Total rents received</span>
                <span className="font-semibold text-emerald-600">{formatCurrency(grandIncome)}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-200">
                <span className="text-gray-600">Total expenses</span>
                <span className="font-semibold text-red-500">{formatCurrency(grandExpenses)}</span>
              </div>
              <div className="flex justify-between py-2 font-semibold text-base">
                <span>Total net income / (loss)</span>
                <span className={grandNet >= 0 ? 'text-emerald-600' : 'text-red-600'}>
                  {grandNet < 0 ? `(${formatCurrency(Math.abs(grandNet))})` : formatCurrency(grandNet)}
                </span>
              </div>
            </div>
            <div className="mt-5 pt-4 border-t border-gray-200 text-xs text-gray-400 leading-relaxed max-w-2xl">
              Transfer the total net income or (loss) to Schedule 1 (Form 1040), Line 5. Net losses may be subject
              to passive activity loss rules — see Form 8582. Consult a qualified tax professional before filing.
              Depreciation figures above are calculated using IRS straight-line mid-month convention.
            </div>
          </div>
        </>
      )}
    </div>
  )
}
