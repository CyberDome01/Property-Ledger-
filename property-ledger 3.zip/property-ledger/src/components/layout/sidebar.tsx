'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { cn, getInitials } from '@/lib/utils'
import type { Profile, Subscription } from '@/types'
import type { User } from '@supabase/supabase-js'

interface SidebarProps {
  user: User
  profile: Profile | null
  subscription: Subscription | null
}

const navItems = [
  { href: '/dashboard',    label: 'Dashboard' },
  { href: '/properties',   label: 'Properties' },
  { href: '/transactions', label: 'Transactions' },
  { href: '/leases',       label: 'Leases' },
  { href: '/schedule-e',   label: 'Schedule E' },
  { href: '/reports',      label: 'Reports' },
]

export default function Sidebar({ user, profile, subscription }: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()

  const isTrialing = subscription?.status === 'trialing'
  const daysLeft = subscription?.trial_ends_at
    ? Math.max(0, Math.ceil((new Date(subscription.trial_ends_at).getTime() - Date.now()) / 86400000))
    : 0

  async function signOut() {
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  const displayName = profile?.full_name || user.email || 'Account'
  const initials = getInitials(displayName)

  return (
    <aside className="w-56 shrink-0 h-screen flex flex-col bg-white border-r border-gray-200">
      {/* Logo */}
      <div className="h-14 px-4 flex items-center border-b border-gray-100">
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="w-7 h-7 bg-brand-600 rounded-lg flex items-center justify-center shrink-0">
            <span className="text-white text-xs font-bold">PL</span>
          </div>
          <span className="font-semibold text-gray-900 text-sm">PropertyLedger</span>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map(({ href, label }) => {
          const active = pathname === href || pathname.startsWith(href + '/')
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex items-center h-8 px-3 rounded-lg text-sm transition-colors',
                active
                  ? 'bg-brand-50 text-brand-700 font-medium'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900',
              )}
            >
              {label}
            </Link>
          )
        })}

        <div className="pt-4 pb-1">
          <div className="px-3 text-xs font-semibold text-gray-400 uppercase tracking-wider">Account</div>
        </div>
        <Link
          href="/settings/billing"
          className={cn(
            'flex items-center h-8 px-3 rounded-lg text-sm transition-colors',
            pathname.startsWith('/settings')
              ? 'bg-brand-50 text-brand-700 font-medium'
              : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900',
          )}
        >
          Billing & Plan
        </Link>
      </nav>

      {/* Trial banner */}
      {isTrialing && daysLeft <= 14 && (
        <div className="mx-2 mb-2 p-3 bg-amber-50 border border-amber-200 rounded-xl">
          <p className="text-xs font-medium text-amber-800">
            {daysLeft === 0 ? 'Trial ended' : `${daysLeft} day${daysLeft === 1 ? '' : 's'} left in trial`}
          </p>
          <Link href="/settings/billing" className="text-xs text-amber-700 underline mt-0.5 block">
            Upgrade now
          </Link>
        </div>
      )}

      {/* User */}
      <div className="p-3 border-t border-gray-100">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center shrink-0">
            <span className="text-xs font-semibold text-brand-700">{initials}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-gray-900 truncate">{displayName}</p>
            <p className="text-xs text-gray-400 truncate">{user.email}</p>
          </div>
          <button
            onClick={signOut}
            className="text-xs text-gray-400 hover:text-gray-600 transition-colors shrink-0"
            title="Sign out"
          >
            Out
          </button>
        </div>
      </div>
    </aside>
  )
}
