'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { PROPERTY_TYPES } from '@/lib/constants'

export default function PropertyForm({ defaultValues }: { defaultValues?: Record<string, string | number | boolean> }) {
  const router = useRouter()
  const supabase = createClient()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError('')
    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const fd = new FormData(e.currentTarget)
    const payload = {
      user_id: user.id,
      name: fd.get('name') as string,
      address: fd.get('address') as string,
      city: fd.get('city') as string || null,
      state_province: fd.get('state_province') as string || null,
      zip_postal: fd.get('zip_postal') as string || null,
      country: fd.get('country') as string || 'US',
      property_type: fd.get('property_type') as string,
      monthly_rent: parseFloat(fd.get('monthly_rent') as string) || 0,
      purchase_price: parseFloat(fd.get('purchase_price') as string) || null,
      purchase_date: fd.get('purchase_date') as string || null,
      bedrooms: parseInt(fd.get('bedrooms') as string) || null,
      bathrooms: parseFloat(fd.get('bathrooms') as string) || null,
      square_feet: parseInt(fd.get('square_feet') as string) || null,
      notes: fd.get('notes') as string || null,
    }

    const { error } = await supabase.schema('pl').from('properties').insert(payload)
    if (error) { setError(error.message); setLoading(false); return }
    router.push('/properties')
    router.refresh()
  }

  return (
    <div className="card p-6 mb-6">
      <h3 className="mb-5">Add property</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Property name *</label>
            <input name="name" className="input" placeholder="123 Maple St" required defaultValue={defaultValues?.name as string} />
          </div>
          <div>
            <label className="label">Property type *</label>
            <select name="property_type" className="select" defaultValue={defaultValues?.property_type as string || 'Single Family'}>
              {PROPERTY_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="label">Street address *</label>
          <input name="address" className="input" placeholder="123 Maple Street" required defaultValue={defaultValues?.address as string} />
        </div>
        <div className="grid grid-cols-4 gap-3">
          <div className="col-span-2">
            <label className="label">City</label>
            <input name="city" className="input" placeholder="Springfield" defaultValue={defaultValues?.city as string} />
          </div>
          <div>
            <label className="label">State / Province</label>
            <input name="state_province" className="input" placeholder="IL" defaultValue={defaultValues?.state_province as string} />
          </div>
          <div>
            <label className="label">ZIP / Postal</label>
            <input name="zip_postal" className="input" placeholder="62701" defaultValue={defaultValues?.zip_postal as string} />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="label">Monthly rent ($)</label>
            <input name="monthly_rent" type="number" step="0.01" min="0" className="input" placeholder="1500" defaultValue={defaultValues?.monthly_rent as number} />
          </div>
          <div>
            <label className="label">Purchase price ($)</label>
            <input name="purchase_price" type="number" step="0.01" min="0" className="input" placeholder="350000" defaultValue={defaultValues?.purchase_price as number} />
          </div>
          <div>
            <label className="label">Purchase date</label>
            <input name="purchase_date" type="date" className="input" defaultValue={defaultValues?.purchase_date as string} />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="label">Bedrooms</label>
            <input name="bedrooms" type="number" min="0" step="1" className="input" placeholder="3" defaultValue={defaultValues?.bedrooms as number} />
          </div>
          <div>
            <label className="label">Bathrooms</label>
            <input name="bathrooms" type="number" min="0" step="0.5" className="input" placeholder="2" defaultValue={defaultValues?.bathrooms as number} />
          </div>
          <div>
            <label className="label">Square feet</label>
            <input name="square_feet" type="number" min="0" className="input" placeholder="1200" defaultValue={defaultValues?.square_feet as number} />
          </div>
        </div>
        <div>
          <label className="label">Notes</label>
          <textarea name="notes" className="input h-20 resize-none py-2" placeholder="Optional notes..." defaultValue={defaultValues?.notes as string} />
        </div>
        {error && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</p>}
        <div className="flex items-center gap-3 pt-1">
          <Button type="submit" loading={loading}>Save property</Button>
          <Button type="button" variant="ghost" onClick={() => router.push('/properties')}>Cancel</Button>
        </div>
      </form>
    </div>
  )
}
