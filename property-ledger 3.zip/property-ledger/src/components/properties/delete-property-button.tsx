'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'

export default function DeletePropertyButton({ propertyId }: { propertyId: string }) {
  const router = useRouter()
  const supabase = createClient()
  const [loading, setLoading] = useState(false)

  async function handleDelete() {
    if (!confirm('Delete this property? All associated transactions and leases will also be removed. This cannot be undone.')) return
    setLoading(true)
    await supabase.schema('pl').from('properties').delete().eq('id', propertyId)
    router.push('/properties')
    router.refresh()
  }

  return (
    <Button variant="outline" size="sm" onClick={handleDelete} loading={loading}
      className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-700">
      Delete property
    </Button>
  )
}
