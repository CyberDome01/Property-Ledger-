'use client'

import { useState, useMemo } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { formatCurrency, formatDate, daysUntil } from '@/lib/utils'

interface Property { id: string; name: string }
interface Lease {
  id: string; property_id: string; tenant_name: string; tenant_email: string | null
  tenant_phone: string | null; start_date: string; end_date: string | null
  monthly_rent: number; security_deposit: number; is_active: boolean; notes: string | null
  properties?: { id: string; name: string; address: string } | null
}

interface Props { properties: Property[]; initialLeases: Lease[]; showForm: boolean }

export default function LeasesClient({ properties, initialLeases, showForm: initShow }: Props) {
  const supabase = createClient()
  const [leases, setLeases] = useState(initialLeases)
  const [showForm, setShowForm] = useState(initShow)
  const [filterStatus, setFilterStatus] = useState('active')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const filtered = useMemo(() =>
    leases.filter((l) => {
      if (filterStatus === 'active') return l.is_active
      if (filterStatus === 'inactive') return !l.is_active
      return true
    }), [leases, filterStatus])

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setError(''); setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const fd = new FormData(e.currentTarget)
    const payload = {
      user_id: user.id,
      property_id: fd.get('property_id') as string,
      tenant_name: fd.get('tenant_name') as string,
      tenant_email: fd.get('tenant_email') as string || null,
      tenant_phone: fd.get('tenant_phone') as string || null,
      start_date: fd.get('start_date') as string,
      end_date: fd.get('end_date') as string || null,
      monthly_rent: parseFloat(fd.get('monthly_rent') as string) || 0,
      security_deposit: parseFloat(fd.get('security_deposit') as string) || 0,
      notes: fd.get('notes') as string || null,
    }
    if (!payload.property_id || !payload.tenant_name || !payload.start_date) {
      setError('Property, tenant name and start date are required'); setLoading(false); return
    }
    const { data, error } = await supabase.schema('pl').from('leases')
      .insert(payload).select('*, properties:pl.properties(id,name,address)').single()
    if (error) { setError(error.message); setLoading(false); return }
    setLeases((prev) => [data, ...prev])
    setShowForm(false); setLoading(false)
    ;(e.target as HTMLFormElement).reset()
  }

  async function toggleActive(lease: Lease) {
    await supabase.schema('pl').from('leases').update({ is_active: !lease.is_active }).eq('id', lease.id)
    setLeases((prev) => prev.map((l) => l.id === lease.id ? { ...l, is_active: !l.is_active } : l))
  }

  async function deleteLease(id: string) {
    if (!confirm('Delete this lease record?')) return
    await supabase.schema('pl').from('leases').delete().eq('id', id)
    setLeases((prev) => prev.filter((l) => l.id !== id))
  }

  function leaseStatus(lease: Lease) {
    if (!lease.is_active) return { label: 'Inactive', className: 'bg-gray-100 text-gray-500' }
    if (!lease.end_date) return { label: 'Month-to-month', className: 'bg-blue-50 text-blue-700' }
    const days = daysUntil(lease.end_date)
    if (days < 0) return { label: 'Expired', className: 'bg-red-50 text-red-700' }
    if (days <= 30) return { label: `Expires in ${days}d`, className: 'bg-red-50 text-red-700' }
    if (days <= 90) return { label: `Expires in ${days}d`, className: 'bg-amber-50 text-amber-700' }
    return { label: 'Active', className: 'bg-emerald-50 text-emerald-700' }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Leases</h1>
          <p className="text-sm text-gray-500 mt-0.5">{leases.filter((l) => l.is_active).length} active</p>
        </div>
        <Button size="sm" onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Close' : 'Add lease'}
        </Button>
      </div>

      {showForm && (
        <div className="card p-5 mb-6">
          <h3 className="mb-4">New lease</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="label">Property *</label>
                <select name="property_id" className="select" required>
                  <option value="">Select property</option>
                  {properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Tenant name *</label>
                <input name="tenant_name" className="input" placeholder="Jane Smith" required />
              </div>
              <div>
                <label className="label">Tenant email</label>
                <input name="tenant_email" type="email" className="input" placeholder="jane@example.com" />
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="label">Tenant phone</label>
                <input name="tenant_phone" className="input" placeholder="+1 555 000 0000" />
              </div>
              <div>
                <label className="label">Start date *</label>
                <input name="start_date" type="date" className="input" required />
              </div>
              <div>
                <label className="label">End date</label>
                <input name="end_date" type="date" className="input" />
              </div>
              <div>
                <label className="label">Monthly rent ($)</label>
                <input name="monthly_rent" type="number" step="0.01" min="0" className="input" placeholder="1500" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Security deposit ($)</label>
                <input name="security_deposit" type="number" step="0.01" min="0" className="input" placeholder="3000" />
              </div>
              <div>
                <label className="label">Notes</label>
                <input name="notes" className="input" placeholder="Optional notes" />
              </div>
            </div>
            {error && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</p>}
            <div className="flex gap-3">
              <Button type="submit" loading={loading}>Save lease</Button>
              <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </form>
        </div>
      )}

      {/* Filter */}
      <div className="flex gap-2 mb-4">
        {['all', 'active', 'inactive'].map((s) => (
          <button key={s}
            onClick={() => setFilterStatus(s)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${filterStatus === s ? 'bg-gray-900 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
            {s}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card p-10 text-center">
          <p className="text-gray-400 text-sm">No leases found. Add your first lease to track tenants and expiry dates.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((l) => {
            const status = leaseStatus(l)
            return (
              <div key={l.id} className="card p-5">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 flex-wrap mb-1">
                      <h3 className="text-base">{l.tenant_name}</h3>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${status.className}`}>
                        {status.label}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">{l.properties?.name} · {l.properties?.address}</p>
                    {(l.tenant_email || l.tenant_phone) && (
                      <p className="text-xs text-gray-400 mt-0.5">{l.tenant_email}{l.tenant_phone ? ` · ${l.tenant_phone}` : ''}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={() => toggleActive(l)}>
                      {l.is_active ? 'Mark inactive' : 'Mark active'}
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => deleteLease(l.id)} className="text-red-400 hover:text-red-600 hover:bg-red-50">
                      Delete
                    </Button>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-400">Monthly rent</p>
                    <p className="text-sm font-semibold">{formatCurrency(Number(l.monthly_rent))}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-400">Security deposit</p>
                    <p className="text-sm font-semibold">{formatCurrency(Number(l.security_deposit))}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-400">Start date</p>
                    <p className="text-sm font-semibold">{formatDate(l.start_date)}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-400">End date</p>
                    <p className="text-sm font-semibold">{l.end_date ? formatDate(l.end_date) : 'Month-to-month'}</p>
                  </div>
                </div>
                {l.notes && <p className="text-xs text-gray-400 mt-3 border-t border-gray-100 pt-3">{l.notes}</p>}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
