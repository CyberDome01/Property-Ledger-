import { daysUntil, formatDate } from '@/lib/utils'
import Link from 'next/link'

interface Lease {
  id: string; tenant_name: string; end_date: string | null; property_id: string
  properties?: { name: string } | null
}

export default function LeaseAlerts({ leases, allLeases }: { leases: Lease[]; allLeases: Lease[] }) {
  const occupied = allLeases.length
  if (!allLeases.length) {
    return (
      <div className="px-5 py-8 text-center">
        <p className="text-sm text-gray-400 mb-2">No active leases.</p>
        <Link href="/leases?action=new" className="text-xs text-brand-600 font-medium hover:underline">Add a lease</Link>
      </div>
    )
  }

  return (
    <div>
      <div className="px-5 py-3 bg-gray-50 border-b border-gray-100">
        <p className="text-xs text-gray-500">{occupied} active lease{occupied !== 1 ? 's' : ''}</p>
      </div>
      {leases.length === 0 ? (
        <div className="px-5 py-4 text-sm text-gray-400">No leases expiring in 90 days.</div>
      ) : (
        <div className="divide-y divide-gray-50">
          {leases.map((l) => {
            const days = l.end_date ? daysUntil(l.end_date) : null
            const urgent = days !== null && days <= 30
            return (
              <div key={l.id} className="px-5 py-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{l.tenant_name}</p>
                    <p className="text-xs text-gray-400">{l.properties?.name}</p>
                  </div>
                  {l.end_date && (
                    <div className="text-right shrink-0">
                      <span className={`text-xs font-semibold ${urgent ? 'text-red-600' : 'text-amber-600'}`}>
                        {days === 0 ? 'Today' : `${days}d`}
                      </span>
                      <p className="text-xs text-gray-400">{formatDate(l.end_date)}</p>
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
