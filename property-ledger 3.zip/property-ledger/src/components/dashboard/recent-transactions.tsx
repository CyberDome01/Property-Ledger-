import { formatDate, formatCurrency } from '@/lib/utils'

interface Txn {
  id: string; date: string; type: string; category: string; amount: number; description: string | null; property_id: string | null
}
interface Prop { id: string; name: string }

export default function RecentTransactions({ transactions, properties }: { transactions: Txn[]; properties: Prop[] }) {
  const propMap = Object.fromEntries(properties.map((p) => [p.id, p.name]))

  if (!transactions.length) {
    return (
      <div className="px-5 py-8 text-center">
        <p className="text-sm text-gray-400">No transactions yet.</p>
      </div>
    )
  }

  return (
    <div className="divide-y divide-gray-50">
      {transactions.map((t) => (
        <div key={t.id} className="px-5 py-3 flex items-center justify-between gap-4 hover:bg-gray-50 transition-colors">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className={t.type === 'income' ? 'badge-income' : 'badge-expense'}>{t.category}</span>
            </div>
            <div className="text-xs text-gray-400 mt-0.5">
              {t.property_id ? propMap[t.property_id] : 'All properties'} · {formatDate(t.date)}
              {t.description && ` · ${t.description}`}
            </div>
          </div>
          <span className={`text-sm font-semibold shrink-0 ${t.type === 'income' ? 'text-emerald-600' : 'text-red-500'}`}>
            {t.type === 'income' ? '+' : '-'}{formatCurrency(Number(t.amount))}
          </span>
        </div>
      ))}
    </div>
  )
}
