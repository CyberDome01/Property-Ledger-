'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { formatDate } from '@/lib/utils'
import { PLANS } from '@/lib/constants'
import type { Subscription } from '@/types'

interface Props {
  subscription: Subscription | null
  userEmail: string
}

export default function BillingClient({ subscription, userEmail }: Props) {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual')
  const [loading, setLoading] = useState<string | null>(null)

  const currentPlan = subscription?.plan || 'trial'
  const isTrialing = subscription?.status === 'trialing'
  const isActive = subscription?.status === 'active'

  const daysLeft = subscription?.trial_ends_at
    ? Math.max(0, Math.ceil((new Date(subscription.trial_ends_at).getTime() - Date.now()) / 86400000))
    : 0

  async function handleUpgrade(planId: string) {
    setLoading(planId)
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId, billingCycle }),
      })
      const { url } = await res.json()
      if (url) window.location.href = url
    } catch {
      alert('Failed to start checkout. Please try again.')
    }
    setLoading(null)
  }

  async function handleManageBilling() {
    setLoading('portal')
    const res = await fetch('/api/stripe/portal', { method: 'POST' })
    const { url } = await res.json()
    if (url) window.location.href = url
    setLoading(null)
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Billing & Plan</h1>
          <p className="text-sm text-gray-500 mt-0.5">Manage your subscription</p>
        </div>
      </div>

      {/* Current status */}
      <div className="card p-5 mb-8">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <p className="text-xs text-gray-500 mb-1">Current plan</p>
            <div className="flex items-center gap-2">
              <span className="text-lg font-semibold capitalize">{currentPlan}</span>
              <span className={isTrialing ? 'badge-trial' : isActive ? 'badge-active' : 'badge-expense'}>
                {isTrialing ? `Trial — ${daysLeft}d left` : subscription?.status || 'inactive'}
              </span>
            </div>
            <p className="text-sm text-gray-400 mt-0.5">{userEmail}</p>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            {(isActive && subscription?.current_period_end) && (
              <p className="text-xs text-gray-400">
                {subscription.cancel_at_period_end ? 'Cancels' : 'Renews'} {formatDate(subscription.current_period_end)}
              </p>
            )}
            {isActive && (
              <Button variant="outline" size="sm" onClick={handleManageBilling} loading={loading === 'portal'}>
                Manage billing
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Billing cycle toggle */}
      <div className="flex items-center gap-1 p-1 bg-gray-100 rounded-xl w-fit mb-6">
        {(['monthly', 'annual'] as const).map((cycle) => (
          <button key={cycle}
            onClick={() => setBillingCycle(cycle)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all capitalize ${billingCycle === cycle ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>
            {cycle}
            {cycle === 'annual' && <span className="ml-1.5 text-xs text-brand-600 font-semibold">Save 25%</span>}
          </button>
        ))}
      </div>

      {/* Plan cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {PLANS.map((plan, i) => {
          const isCurrent = currentPlan === plan.id
          const price = billingCycle === 'annual' ? plan.annualPrice : plan.monthlyPrice
          return (
            <div key={plan.id} className={`card p-6 flex flex-col ${i === 1 ? 'border-2 border-brand-500' : ''} ${isCurrent ? 'bg-brand-50' : ''}`}>
              {i === 1 && (
                <div className="text-xs font-semibold text-brand-600 uppercase tracking-wider mb-3">Most popular</div>
              )}
              <div className="mb-5">
                <h3 className="text-base mb-1">{plan.name}</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold">${price}</span>
                  <span className="text-sm text-gray-400">/mo</span>
                </div>
                {billingCycle === 'annual' && (
                  <p className="text-xs text-gray-400 mt-0.5">Billed ${plan.annualPrice * 12}/year</p>
                )}
              </div>
              <ul className="space-y-2.5 flex-1 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-gray-600">
                    <svg className="w-4 h-4 text-brand-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
              {isCurrent ? (
                <div className="w-full h-9 flex items-center justify-center text-sm font-medium text-brand-700 bg-brand-100 rounded-lg">
                  Current plan
                </div>
              ) : (
                <Button
                  className="w-full"
                  variant={i === 1 ? 'primary' : 'outline'}
                  loading={loading === plan.id}
                  onClick={() => handleUpgrade(plan.id)}
                >
                  {isActive ? 'Switch to ' : 'Upgrade to '}{plan.name}
                </Button>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
