import Stripe from 'stripe'
import { PLANS } from './constants'
import type { Plan } from '@/types'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-09-30.acacia',
  typescript: true,
})

export async function getOrCreateStripeCustomer(
  userId: string,
  email: string,
  name?: string,
): Promise<string> {
  const customers = await stripe.customers.list({ email, limit: 1 })

  if (customers.data.length > 0) {
    return customers.data[0].id
  }

  const customer = await stripe.customers.create({
    email,
    name: name || email,
    metadata: { supabase_user_id: userId },
  })

  return customer.id
}

export function getPlanFromPriceId(priceId: string): Plan {
  for (const plan of PLANS) {
    if (
      plan.stripePriceMonthly === priceId ||
      plan.stripePriceAnnual === priceId
    ) {
      return plan.id
    }
  }
  return 'starter'
}

export function getPlanConfig(planId: Plan) {
  return PLANS.find((p) => p.id === planId) ?? PLANS[0]
}
