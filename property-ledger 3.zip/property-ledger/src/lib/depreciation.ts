import {
  RESIDENTIAL_DEPRECIATION_YEARS,
  COMMERCIAL_DEPRECIATION_YEARS,
  DEFAULT_LAND_VALUE_PERCENT,
} from './constants'
import type { Property } from '@/types'

export interface DepreciationResult {
  annualDepreciation: number
  depreciableBasis: number
  landValue: number
  totalYears: number
  accumulatedDepreciation: number
  remainingBasis: number
}

/**
 * Calculates straight-line depreciation for a rental property.
 * Residential: 27.5 years. Commercial: 39 years.
 * Land is excluded from the depreciable basis.
 */
export function calculateDepreciation(
  property: Property,
  taxYear: number,
  landValuePercent = DEFAULT_LAND_VALUE_PERCENT,
): DepreciationResult | null {
  if (!property.purchase_price || !property.purchase_date) return null

  const purchaseYear = new Date(property.purchase_date).getFullYear()
  const purchaseMonth = new Date(property.purchase_date).getMonth() // 0-indexed
  const yearsHeld = taxYear - purchaseYear

  if (yearsHeld < 0) return null

  const isCommercial = property.property_type === 'Commercial'
  const totalYears = isCommercial
    ? COMMERCIAL_DEPRECIATION_YEARS
    : RESIDENTIAL_DEPRECIATION_YEARS

  const landValue = property.purchase_price * landValuePercent
  const depreciableBasis = property.purchase_price - landValue
  const fullYearDepreciation = depreciableBasis / totalYears

  // IRS mid-month convention: partial year in year of acquisition
  // Months available = 12 - purchaseMonth + 0.5 (mid-month)
  const monthsInFirstYear = 12 - purchaseMonth - 0.5
  const firstYearDepreciation = (fullYearDepreciation * monthsInFirstYear) / 12

  let annualDepreciation: number
  if (yearsHeld === 0) {
    annualDepreciation = firstYearDepreciation
  } else if (yearsHeld < totalYears) {
    annualDepreciation = fullYearDepreciation
  } else {
    annualDepreciation = 0 // fully depreciated
  }

  // Accumulated through end of taxYear
  const accumulated =
    Math.min(firstYearDepreciation, depreciableBasis) +
    Math.min(fullYearDepreciation * Math.max(0, yearsHeld - 1), depreciableBasis - firstYearDepreciation)

  return {
    annualDepreciation: Math.round(annualDepreciation * 100) / 100,
    depreciableBasis: Math.round(depreciableBasis * 100) / 100,
    landValue: Math.round(landValue * 100) / 100,
    totalYears,
    accumulatedDepreciation: Math.round(Math.min(accumulated, depreciableBasis) * 100) / 100,
    remainingBasis: Math.round(Math.max(depreciableBasis - accumulated, 0) * 100) / 100,
  }
}
