import type { PlanConfig } from '@/types'

export const INCOME_CATEGORIES = [
  'Rent received',
  'Late fees',
  'Pet fees',
  'Parking fees',
  'Laundry income',
  'Storage fees',
  'Lease termination fees',
  'Other income',
] as const

export const EXPENSE_CATEGORIES = [
  'Advertising',
  'Auto and travel',
  'Cleaning and maintenance',
  'Commissions',
  'Insurance',
  'Legal and professional fees',
  'Management fees',
  'Mortgage interest (banks)',
  'Other interest',
  'Repairs',
  'Supplies',
  'Taxes',
  'Utilities',
  'Depreciation',
  'Other expenses',
] as const

export const PROPERTY_TYPES = [
  'Single Family',
  'Condo/Townhouse',
  'Multi-Family',
  'Commercial',
  'Vacation Rental',
  'Other',
] as const

export const PLANS: PlanConfig[] = [
  {
    id: 'starter',
    name: 'Starter',
    monthlyPrice: 12,
    annualPrice: 9,
    propertyLimit: 3,
    features: [
      'Up to 3 rental properties',
      'Unlimited transactions',
      'Schedule E reports',
      'Basic dashboard',
      'CSV export',
      'Email support',
    ],
    stripePriceMonthly: process.env.STRIPE_PRICE_STARTER_MONTHLY,
    stripePriceAnnual: process.env.STRIPE_PRICE_STARTER_ANNUAL,
  },
  {
    id: 'pro',
    name: 'Pro',
    monthlyPrice: 24,
    annualPrice: 18,
    propertyLimit: 15,
    features: [
      'Up to 15 rental properties',
      'Everything in Starter',
      'Depreciation calculator',
      'Lease & tenant tracking',
      'Occupancy reporting',
      'Recurring transactions',
      'Receipt storage',
      'Priority support',
    ],
    stripePriceMonthly: process.env.STRIPE_PRICE_PRO_MONTHLY,
    stripePriceAnnual: process.env.STRIPE_PRICE_PRO_ANNUAL,
  },
  {
    id: 'portfolio',
    name: 'Portfolio',
    monthlyPrice: 49,
    annualPrice: 37,
    propertyLimit: null,
    features: [
      'Unlimited properties',
      'Everything in Pro',
      'Accountant sharing link',
      'Multi-year comparisons',
      'Net worth tracking',
      'Portfolio-level analytics',
      'Dedicated support',
    ],
    stripePriceMonthly: process.env.STRIPE_PRICE_PORTFOLIO_MONTHLY,
    stripePriceAnnual: process.env.STRIPE_PRICE_PORTFOLIO_ANNUAL,
  },
]

export const PLAN_PROPERTY_LIMITS: Record<string, number | null> = {
  trial: 2,
  starter: 3,
  pro: 15,
  portfolio: null,
}

// 27.5-year straight-line depreciation for residential rental property
export const RESIDENTIAL_DEPRECIATION_YEARS = 27.5
// 39-year for commercial
export const COMMERCIAL_DEPRECIATION_YEARS = 39
// Land value is typically 20-30% of purchase price — not depreciable
export const DEFAULT_LAND_VALUE_PERCENT = 0.2
