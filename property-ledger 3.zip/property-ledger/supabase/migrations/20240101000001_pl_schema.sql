-- PropertyLedger schema — isolated under the `pl` namespace
-- Run this on any fresh Supabase project to bootstrap the app.

CREATE SCHEMA IF NOT EXISTS pl;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── profiles ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pl.profiles (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name     TEXT,
  email         TEXT,
  avatar_url    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── subscriptions ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pl.subscriptions (
  id                       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id                  UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  stripe_customer_id       TEXT,
  stripe_subscription_id   TEXT UNIQUE,
  plan                     TEXT NOT NULL DEFAULT 'trial'
                             CHECK (plan IN ('trial','starter','pro','portfolio')),
  status                   TEXT NOT NULL DEFAULT 'trialing'
                             CHECK (status IN ('trialing','active','canceled','past_due','incomplete')),
  trial_ends_at            TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '14 days'),
  current_period_end       TIMESTAMPTZ,
  cancel_at_period_end     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id)
);

-- ─── properties ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pl.properties (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  address         TEXT NOT NULL,
  city            TEXT,
  state_province  TEXT,
  zip_postal      TEXT,
  country         TEXT NOT NULL DEFAULT 'US',
  property_type   TEXT NOT NULL DEFAULT 'Single Family',
  monthly_rent    NUMERIC(12,2) NOT NULL DEFAULT 0,
  purchase_price  NUMERIC(12,2),
  purchase_date   DATE,
  bedrooms        SMALLINT,
  bathrooms       NUMERIC(3,1),
  square_feet     INTEGER,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── transactions ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pl.transactions (
  id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id              UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  property_id          UUID REFERENCES pl.properties(id) ON DELETE SET NULL,
  date                 DATE NOT NULL,
  type                 TEXT NOT NULL CHECK (type IN ('income','expense')),
  category             TEXT NOT NULL,
  description          TEXT,
  amount               NUMERIC(12,2) NOT NULL,
  is_recurring         BOOLEAN NOT NULL DEFAULT FALSE,
  recurring_frequency  TEXT CHECK (recurring_frequency IN ('monthly','quarterly','annually')),
  receipt_url          TEXT,
  vendor               TEXT,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── leases ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pl.leases (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id          UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  property_id      UUID NOT NULL REFERENCES pl.properties(id) ON DELETE CASCADE,
  tenant_name      TEXT NOT NULL,
  tenant_email     TEXT,
  tenant_phone     TEXT,
  start_date       DATE NOT NULL,
  end_date         DATE,
  monthly_rent     NUMERIC(12,2) NOT NULL,
  security_deposit NUMERIC(12,2) NOT NULL DEFAULT 0,
  is_active        BOOLEAN NOT NULL DEFAULT TRUE,
  notes            TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── indexes ─────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_pl_properties_user_id       ON pl.properties(user_id);
CREATE INDEX IF NOT EXISTS idx_pl_transactions_user_id     ON pl.transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_pl_transactions_property_id ON pl.transactions(property_id);
CREATE INDEX IF NOT EXISTS idx_pl_transactions_date        ON pl.transactions(date DESC);
CREATE INDEX IF NOT EXISTS idx_pl_leases_user_id           ON pl.leases(user_id);
CREATE INDEX IF NOT EXISTS idx_pl_leases_property_id       ON pl.leases(property_id);
CREATE INDEX IF NOT EXISTS idx_pl_leases_end_date          ON pl.leases(end_date);

-- ─── updated_at triggers ─────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION pl.update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pl, public AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$;

CREATE OR REPLACE TRIGGER profiles_updated_at
  BEFORE UPDATE ON pl.profiles FOR EACH ROW EXECUTE FUNCTION pl.update_updated_at();
CREATE OR REPLACE TRIGGER subscriptions_updated_at
  BEFORE UPDATE ON pl.subscriptions FOR EACH ROW EXECUTE FUNCTION pl.update_updated_at();
CREATE OR REPLACE TRIGGER properties_updated_at
  BEFORE UPDATE ON pl.properties FOR EACH ROW EXECUTE FUNCTION pl.update_updated_at();
CREATE OR REPLACE TRIGGER transactions_updated_at
  BEFORE UPDATE ON pl.transactions FOR EACH ROW EXECUTE FUNCTION pl.update_updated_at();
CREATE OR REPLACE TRIGGER leases_updated_at
  BEFORE UPDATE ON pl.leases FOR EACH ROW EXECUTE FUNCTION pl.update_updated_at();

-- ─── auto-provision on signup ─────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION pl.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pl, public, auth AS $$
BEGIN
  INSERT INTO pl.profiles (id, full_name, email)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.email)
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO pl.subscriptions (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS pl_on_auth_user_created ON auth.users;
CREATE TRIGGER pl_on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION pl.handle_new_user();

-- ─── row level security ───────────────────────────────────────────────────────
ALTER TABLE pl.profiles      ENABLE ROW LEVEL SECURITY;
ALTER TABLE pl.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE pl.properties    ENABLE ROW LEVEL SECURITY;
ALTER TABLE pl.transactions  ENABLE ROW LEVEL SECURITY;
ALTER TABLE pl.leases        ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own_profile"       ON pl.profiles      FOR ALL USING (auth.uid() = id);
CREATE POLICY "own_subscription"  ON pl.subscriptions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "svc_subscription"  ON pl.subscriptions FOR ALL TO service_role USING (true);
CREATE POLICY "own_properties"    ON pl.properties    FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_transactions"  ON pl.transactions  FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_leases"        ON pl.leases        FOR ALL USING (auth.uid() = user_id);
